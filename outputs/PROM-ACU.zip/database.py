"""SQLite persistence helpers for PROM-ACU."""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

import pandas as pd


DB_PATH = Path(__file__).resolve().parent / "prom_acu.db"


@contextmanager
def get_connection() -> Iterator[sqlite3.Connection]:
    """Open a SQLite connection and always close it."""
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def init_db() -> None:
    """Create the database tables and indexes when they do not exist."""
    with get_connection() as connection:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS patients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                dni TEXT NOT NULL UNIQUE,
                age INTEGER NOT NULL CHECK (age BETWEEN 0 AND 120),
                sex TEXT NOT NULL,
                phone TEXT,
                diagnosis TEXT NOT NULL,
                main_complaint TEXT NOT NULL,
                assigned_scale TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                patient_id INTEGER NOT NULL,
                session_number INTEGER NOT NULL CHECK (session_number > 0),
                date TEXT NOT NULL,
                eva_pre REAL NOT NULL CHECK (eva_pre BETWEEN 0 AND 10),
                eva_post REAL NOT NULL CHECK (eva_post BETWEEN 0 AND 10),
                analgesic_use INTEGER NOT NULL DEFAULT 0,
                adverse_event INTEGER NOT NULL DEFAULT 0,
                adverse_event_description TEXT,
                notes TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
                UNIQUE (patient_id, session_number)
            );

            CREATE INDEX IF NOT EXISTS idx_sessions_patient
            ON sessions(patient_id);

            CREATE INDEX IF NOT EXISTS idx_sessions_patient_date
            ON sessions(patient_id, date);
            """
        )


def add_patient(
    name: str,
    dni: str,
    age: int,
    sex: str,
    phone: str,
    diagnosis: str,
    main_complaint: str,
    assigned_scale: str,
) -> int:
    """Insert a patient and return the generated identifier."""
    with get_connection() as connection:
        cursor = connection.execute(
            """
            INSERT INTO patients (
                name, dni, age, sex, phone, diagnosis,
                main_complaint, assigned_scale
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                name.strip(),
                dni.strip(),
                age,
                sex,
                phone.strip(),
                diagnosis.strip(),
                main_complaint,
                assigned_scale,
            ),
        )
        return int(cursor.lastrowid)


def add_session(
    patient_id: int,
    session_number: int,
    date: str,
    eva_pre: float,
    eva_post: float,
    analgesic_use: bool,
    adverse_event: bool,
    adverse_event_description: str,
    notes: str,
) -> int:
    """Insert a clinical session and return its identifier."""
    with get_connection() as connection:
        cursor = connection.execute(
            """
            INSERT INTO sessions (
                patient_id, session_number, date, eva_pre, eva_post,
                analgesic_use, adverse_event, adverse_event_description, notes
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                patient_id,
                session_number,
                date,
                eva_pre,
                eva_post,
                int(analgesic_use),
                int(adverse_event),
                adverse_event_description.strip(),
                notes.strip(),
            ),
        )
        return int(cursor.lastrowid)


def get_patients() -> pd.DataFrame:
    """Return all patients ordered by name."""
    with get_connection() as connection:
        return pd.read_sql_query(
            "SELECT * FROM patients ORDER BY name COLLATE NOCASE",
            connection,
        )


def get_patient(patient_id: int) -> dict[str, Any] | None:
    """Return one patient as a dictionary."""
    with get_connection() as connection:
        row = connection.execute(
            "SELECT * FROM patients WHERE id = ?",
            (patient_id,),
        ).fetchone()
        return dict(row) if row else None


def get_patient_sessions(patient_id: int) -> pd.DataFrame:
    """Return a patient's sessions in clinical order."""
    with get_connection() as connection:
        return pd.read_sql_query(
            """
            SELECT *
            FROM sessions
            WHERE patient_id = ?
            ORDER BY session_number ASC, date ASC, id ASC
            """,
            connection,
            params=(patient_id,),
        )


def get_dashboard_data() -> pd.DataFrame:
    """Return patient and session data needed by the medical dashboard."""
    with get_connection() as connection:
        return pd.read_sql_query(
            """
            SELECT
                p.id,
                p.name,
                p.dni,
                p.diagnosis,
                p.main_complaint,
                p.assigned_scale,
                (
                    SELECT s.eva_pre
                    FROM sessions s
                    WHERE s.patient_id = p.id
                    ORDER BY s.session_number ASC, s.date ASC, s.id ASC
                    LIMIT 1
                ) AS baseline_eva,
                (
                    SELECT s.eva_pre
                    FROM sessions s
                    WHERE s.patient_id = p.id
                    ORDER BY s.session_number DESC, s.date DESC, s.id DESC
                    LIMIT 1
                ) AS latest_eva,
                COUNT(s2.id) AS session_count
            FROM patients p
            LEFT JOIN sessions s2 ON s2.patient_id = p.id
            GROUP BY p.id
            ORDER BY p.name COLLATE NOCASE
            """,
            connection,
        )


def dni_exists(dni: str) -> bool:
    """Check whether a DNI is already registered."""
    with get_connection() as connection:
        row = connection.execute(
            "SELECT 1 FROM patients WHERE dni = ? LIMIT 1",
            (dni.strip(),),
        ).fetchone()
        return row is not None


def session_number_exists(patient_id: int, session_number: int) -> bool:
    """Check whether a session number is already in use for a patient."""
    with get_connection() as connection:
        row = connection.execute(
            """
            SELECT 1
            FROM sessions
            WHERE patient_id = ? AND session_number = ?
            LIMIT 1
            """,
            (patient_id, session_number),
        ).fetchone()
        return row is not None
