"""Clinical rules and presentation helpers for PROM-ACU."""

from __future__ import annotations

from typing import Any

import pandas as pd


SCALE_BY_COMPLAINT = {
    "Rodilla": "KOOS / WOMAC + EVA",
    "Cadera": "WOMAC + EVA",
    "Lumbalgia": "ODI + EVA",
    "Cervicalgia": "NDI + EVA",
    "Hombro": "SPADI + EVA",
    "Dolor general": "EVA + PGIC",
    "Estrés / ansiedad": "GAD-7 + PSS",
    "Insomnio": "ISI",
    "Digestivo funcional": "IBS-SSS",
    "Respiratorio funcional": "ACT o CAT",
}

MEDICAL_WARNING = (
    "Esta aplicación no reemplaza la consulta médica ni emite diagnósticos. "
    "Solo permite seguimiento clínico."
)


def assigned_scale(main_complaint: str) -> str:
    """Return the scale configured for a main complaint."""
    return SCALE_BY_COMPLAINT.get(main_complaint, "Pendiente de asignación")


def calculate_improvement(
    baseline_eva: float | int | None,
    current_eva: float | int | None,
) -> tuple[float | None, float | None]:
    """Calculate absolute and percentage improvement from EVA values."""
    if baseline_eva is None or current_eva is None:
        return None, None

    baseline = float(baseline_eva)
    current = float(current_eva)
    absolute = baseline - current

    if baseline == 0:
        percentage = 0.0 if current == 0 else -100.0
    else:
        percentage = (absolute / baseline) * 100

    return round(absolute, 1), round(percentage, 1)


def clinical_status(
    baseline_eva: float | int | None,
    current_eva: float | int | None,
) -> str:
    """Classify the clinical response according to MVP thresholds."""
    if baseline_eva is None or current_eva is None:
        return "Sin sesiones"

    baseline = float(baseline_eva)
    current = float(current_eva)
    if current > baseline:
        return "Empeoramiento"

    _, percentage = calculate_improvement(baseline, current)
    if percentage is None:
        return "Sin datos"
    if percentage >= 70:
        return "Excelente respuesta"
    if percentage >= 50:
        return "Muy buena respuesta"
    if percentage >= 30:
        return "Moderada"
    if percentage >= 10:
        return "Leve"
    return "Sin respuesta clara"


def enrich_dashboard_data(data: pd.DataFrame) -> pd.DataFrame:
    """Add calculated improvement and status columns to dashboard data."""
    result = data.copy()
    if result.empty:
        return result

    calculations = result.apply(
        lambda row: calculate_improvement(row["baseline_eva"], row["latest_eva"]),
        axis=1,
    )
    result["absolute_improvement"] = calculations.apply(lambda value: value[0])
    result["improvement_percentage"] = calculations.apply(lambda value: value[1])
    result["clinical_status"] = result.apply(
        lambda row: clinical_status(row["baseline_eva"], row["latest_eva"]),
        axis=1,
    )
    return result


def yes_no(value: Any) -> str:
    """Convert SQLite booleans to Spanish text."""
    return "Sí" if bool(value) else "No"


def build_clinical_report(
    patient: dict[str, Any],
    sessions: pd.DataFrame,
) -> str:
    """Build a plain-text clinical follow-up report."""
    if sessions.empty:
        return (
            f"Paciente {patient['name']}, diagnóstico {patient['diagnosis']}, "
            "registrado/a para seguimiento con acupuntura. "
            "Aún no cuenta con sesiones ni valores EVA registrados."
        )

    baseline_eva = float(sessions.iloc[0]["eva_pre"])
    latest_session = sessions.iloc[-1]
    latest_eva = float(latest_session["eva_pre"])
    _, percentage = calculate_improvement(baseline_eva, latest_eva)
    status = clinical_status(baseline_eva, latest_eva)
    adverse_events = "Sí" if sessions["adverse_event"].astype(bool).any() else "No"
    notes = str(latest_session["notes"]).strip() or "Sin observaciones registradas"

    return (
        f"Paciente {patient['name']}, diagnóstico {patient['diagnosis']}, "
        f"en seguimiento con acupuntura. EVA basal: {baseline_eva:.1f}. "
        f"Última EVA registrada: {latest_eva:.1f}. "
        f"Mejoría porcentual: {percentage:.1f}%. "
        f"Respuesta clínica: {status}. "
        f"Eventos adversos: {adverse_events}. "
        f"Observaciones: {notes}."
    )
