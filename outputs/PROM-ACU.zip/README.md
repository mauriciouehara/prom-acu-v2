# PROM-ACU

Demo funcional en Streamlit para seguimiento clínico de pacientes tratados con
acupuntura mediante EVA, registro de sesiones, gráficos de evolución e informes
automáticos.

> **Advertencia médica:** Esta aplicación no reemplaza la consulta médica ni
> emite diagnósticos. Solo permite seguimiento clínico.

## Funcionalidades del MVP

- Registro de pacientes.
- Asignación automática de escala según el motivo principal.
- Registro de EVA antes y después de cada sesión.
- Registro de analgesia, eventos adversos y observaciones.
- Cálculo de mejoría absoluta y porcentual.
- Clasificación descriptiva de la respuesta clínica.
- Dashboard con resumen por paciente.
- Gráfico de evolución de EVA pre sesión.
- Informe clínico descargable en TXT.
- Persistencia local en SQLite.

Las escalas KOOS, WOMAC, ODI, NDI, SPADI, PGIC, GAD-7, PSS, ISI, IBS-SSS,
ACT y CAT se muestran como asignaciones clínicas, pero sus cuestionarios están
pendientes de implementación. En este MVP solo EVA está implementada.

## Estructura

```text
PROM-ACU/
├── app.py
├── database.py
├── utils.py
├── requirements.txt
└── README.md
```

El archivo `prom_acu.db` se crea automáticamente al iniciar la aplicación.

## Ejecución local

Se requiere Python 3.10 o superior.

1. Crear un entorno virtual:

   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

2. Instalar dependencias:

   ```powershell
   pip install -r requirements.txt
   ```

3. Iniciar la aplicación:

   ```powershell
   streamlit run app.py
   ```

4. Abrir la dirección que Streamlit muestra, normalmente
   `http://localhost:8501`.

## Datos y privacidad

La demo guarda datos en `prom_acu.db` dentro del directorio del proyecto. No
incluye autenticación, cifrado, auditoría, copias de seguridad ni gestión de
consentimiento. Antes de usarla con datos reales deben incorporarse controles
de acceso, protección de datos personales y las medidas regulatorias aplicables.

No se recomienda versionar la base de datos. Puede agregarse esta línea a
`.gitignore`:

```text
prom_acu.db
```

## Despliegue en Streamlit Community Cloud

1. Subir el proyecto a un repositorio de GitHub.
2. Ingresar en [Streamlit Community Cloud](https://share.streamlit.io/).
3. Crear una aplicación y seleccionar el repositorio, la rama y `app.py`.
4. Confirmar que `requirements.txt` esté en la raíz y desplegar.

SQLite funciona para una demo, pero el almacenamiento local de Community Cloud
no debe considerarse persistente. Para un entorno real conviene usar una base
de datos externa administrada y añadir autenticación, autorización, cifrado,
backups y trazabilidad de cambios.

## Alcance clínico

PROM-ACU registra y presenta información aportada por el profesional. No
inventa diagnósticos, no recomienda tratamientos y no reemplaza el juicio
clínico ni la consulta médica.
