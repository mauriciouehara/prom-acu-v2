"""PROM-ACU: simple clinical follow-up demo built with Streamlit."""

from __future__ import annotations

import sqlite3
from datetime import date

import pandas as pd
import plotly.express as px
import streamlit as st

from database import (
    add_patient,
    add_session,
    dni_exists,
    get_dashboard_data,
    get_patient,
    get_patient_sessions,
    get_patients,
    init_db,
    session_number_exists,
)
from utils import (
    MEDICAL_WARNING,
    SCALE_BY_COMPLAINT,
    assigned_scale,
    build_clinical_report,
    clinical_status,
    enrich_dashboard_data,
)


st.set_page_config(
    page_title="PROM-ACU",
    page_icon="🩺",
    layout="wide",
)


def show_medical_warning() -> None:
    """Display the mandatory medical disclaimer."""
    st.warning(MEDICAL_WARNING, icon="⚠️")


def patient_options(patients: pd.DataFrame) -> dict[str, int]:
    """Build readable patient labels mapped to database identifiers."""
    return {
        f"{row['name']} · DNI {row['dni']}": int(row["id"])
        for _, row in patients.iterrows()
    }


def render_home() -> None:
    st.title("PROM-ACU")
    st.subheader("Seguimiento clínico de pacientes tratados con acupuntura")
    show_medical_warning()
    st.markdown(
        """
        Esta demo permite registrar pacientes y sesiones, seguir la evolución
        del dolor mediante EVA, visualizar tendencias y generar un informe
        clínico descriptivo.

        **Alcance del MVP**

        - Registro local y privado en SQLite.
        - EVA antes y después de cada sesión.
        - Cálculo de mejoría absoluta y porcentual.
        - Dashboard y gráfico de evolución.
        - Informe clínico descargable en texto.
        """
    )
    st.info(
        "Las escalas funcionales distintas de EVA se asignan según el motivo "
        "principal, pero su cuestionario está pendiente de implementación."
    )


def render_patient_registration() -> None:
    st.header("Registro de paciente")
    show_medical_warning()

    with st.form("patient_form", clear_on_submit=True):
        col1, col2 = st.columns(2)
        with col1:
            name = st.text_input("Nombre y apellido *", max_chars=120)
            dni = st.text_input("DNI *", max_chars=30)
            age = st.number_input("Edad *", min_value=0, max_value=120, value=18)
            sex = st.selectbox(
                "Sexo *",
                ["Femenino", "Masculino", "Intersexual", "Otro", "Prefiere no informar"],
            )
            phone = st.text_input("Teléfono", max_chars=40)
        with col2:
            diagnosis = st.text_input(
                "Diagnóstico médico principal *",
                max_chars=200,
                help="Registrar únicamente el diagnóstico médico ya existente.",
            )
            complaint = st.selectbox(
                "Motivo principal *",
                list(SCALE_BY_COMPLAINT.keys()),
            )
            scale = assigned_scale(complaint)
            st.text_input("Escala asignada automáticamente", value=scale, disabled=True)
            st.caption(
                "En este MVP solo EVA está implementada. "
                "Las demás escalas quedan pendientes de implementación."
            )

        submitted = st.form_submit_button(
            "Registrar paciente",
            type="primary",
            use_container_width=True,
        )

    if submitted:
        if not name.strip() or not dni.strip() or not diagnosis.strip():
            st.error("Complete todos los campos obligatorios marcados con *.")
            return
        if dni_exists(dni):
            st.error("Ya existe un paciente registrado con ese DNI.")
            return

        try:
            add_patient(
                name=name,
                dni=dni,
                age=int(age),
                sex=sex,
                phone=phone,
                diagnosis=diagnosis,
                main_complaint=complaint,
                assigned_scale=scale,
            )
            st.success("Paciente registrado correctamente.")
        except sqlite3.IntegrityError:
            st.error("No se pudo registrar: revise el DNI y los datos ingresados.")
        except sqlite3.Error as error:
            st.error(f"Error de base de datos: {error}")


def render_session_registration() -> None:
    st.header("Registro de sesión")
    show_medical_warning()
    patients = get_patients()

    if patients.empty:
        st.info("Primero registre al menos un paciente.")
        return

    options = patient_options(patients)
    selected_label = st.selectbox("Seleccionar paciente", list(options.keys()))
    patient_id = options[selected_label]
    existing_sessions = get_patient_sessions(patient_id)
    suggested_number = (
        int(existing_sessions["session_number"].max()) + 1
        if not existing_sessions.empty
        else 1
    )

    with st.form("session_form", clear_on_submit=False):
        col1, col2 = st.columns(2)
        with col1:
            session_number = st.number_input(
                "Número de sesión *",
                min_value=1,
                value=suggested_number,
                step=1,
            )
            session_date = st.date_input(
                "Fecha *",
                value=date.today(),
                max_value=date.today(),
            )
            eva_pre = st.slider(
                "EVA antes de la sesión",
                min_value=0.0,
                max_value=10.0,
                value=5.0,
                step=0.5,
            )
            eva_post = st.slider(
                "EVA después de la sesión",
                min_value=0.0,
                max_value=10.0,
                value=5.0,
                step=0.5,
            )
        with col2:
            analgesic_use = st.radio(
                "Medicación analgésica usada",
                ["No", "Sí"],
                horizontal=True,
            )
            adverse_event = st.radio(
                "Eventos adversos",
                ["No", "Sí"],
                horizontal=True,
            )
            adverse_description = st.text_area(
                "Descripción de eventos adversos",
                max_chars=1000,
                help="Completar cuando se seleccione 'Sí' en eventos adversos.",
            )
            notes = st.text_area("Observaciones clínicas", max_chars=2000)

        submitted = st.form_submit_button(
            "Guardar sesión",
            type="primary",
            use_container_width=True,
        )

    if submitted:
        if adverse_event == "Sí" and not adverse_description.strip():
            st.error("Describa el evento adverso registrado.")
            return
        if session_number_exists(patient_id, int(session_number)):
            st.error("Ese número de sesión ya existe para el paciente.")
            return

        try:
            add_session(
                patient_id=patient_id,
                session_number=int(session_number),
                date=session_date.isoformat(),
                eva_pre=float(eva_pre),
                eva_post=float(eva_post),
                analgesic_use=analgesic_use == "Sí",
                adverse_event=adverse_event == "Sí",
                adverse_event_description=adverse_description,
                notes=notes,
            )
            st.success("Sesión registrada correctamente.")
        except sqlite3.IntegrityError:
            st.error("No se pudo guardar la sesión. Verifique los datos.")
        except sqlite3.Error as error:
            st.error(f"Error de base de datos: {error}")


def render_dashboard() -> None:
    st.header("Dashboard médico")
    show_medical_warning()
    data = enrich_dashboard_data(get_dashboard_data())

    if data.empty:
        st.info("No hay pacientes registrados.")
        return

    total_sessions = int(data["session_count"].sum())
    active_followups = int((data["session_count"] > 0).sum())
    col1, col2, col3 = st.columns(3)
    col1.metric("Pacientes registrados", len(data))
    col2.metric("Pacientes con seguimiento", active_followups)
    col3.metric("Sesiones registradas", total_sessions)

    display = data[
        [
            "name",
            "diagnosis",
            "main_complaint",
            "baseline_eva",
            "latest_eva",
            "improvement_percentage",
            "session_count",
            "clinical_status",
        ]
    ].rename(
        columns={
            "name": "Paciente",
            "diagnosis": "Diagnóstico",
            "main_complaint": "Motivo principal",
            "baseline_eva": "EVA basal",
            "latest_eva": "Última EVA",
            "improvement_percentage": "Mejoría (%)",
            "session_count": "Sesiones",
            "clinical_status": "Estado clínico",
        }
    )

    st.dataframe(
        display,
        use_container_width=True,
        hide_index=True,
        column_config={
            "EVA basal": st.column_config.NumberColumn(format="%.1f"),
            "Última EVA": st.column_config.NumberColumn(format="%.1f"),
            "Mejoría (%)": st.column_config.NumberColumn(format="%.1f%%"),
        },
    )

    st.subheader("Evolución individual")
    options = {
        f"{row['name']} · DNI {row['dni']}": int(row["id"])
        for _, row in data.iterrows()
    }
    selected_label = st.selectbox(
        "Paciente para visualizar",
        list(options.keys()),
        key="dashboard_patient",
    )
    selected_id = options[selected_label]
    patient_row = data.loc[data["id"] == selected_id].iloc[0]
    sessions = get_patient_sessions(selected_id)

    if sessions.empty:
        st.info("Este paciente todavía no tiene sesiones registradas.")
        return

    metric1, metric2, metric3, metric4 = st.columns(4)
    metric1.metric("EVA basal", f"{patient_row['baseline_eva']:.1f}")
    metric2.metric("Última EVA", f"{patient_row['latest_eva']:.1f}")
    metric3.metric(
        "Mejoría",
        f"{patient_row['improvement_percentage']:.1f}%",
    )
    metric4.metric("Estado", patient_row["clinical_status"])

    chart_data = sessions[["session_number", "eva_pre"]].rename(
        columns={"session_number": "Sesión", "eva_pre": "EVA pre sesión"}
    )
    figure = px.line(
        chart_data,
        x="Sesión",
        y="EVA pre sesión",
        markers=True,
        title="Evolución del dolor",
    )
    figure.update_yaxes(range=[0, 10], dtick=1)
    figure.update_xaxes(dtick=1)
    figure.update_layout(hovermode="x unified")
    st.plotly_chart(figure, use_container_width=True)

    st.caption(
        f"Clasificación actual: "
        f"{clinical_status(patient_row['baseline_eva'], patient_row['latest_eva'])}."
    )


def render_report() -> None:
    st.header("Informe clínico")
    show_medical_warning()
    patients = get_patients()

    if patients.empty:
        st.info("No hay pacientes registrados.")
        return

    options = patient_options(patients)
    selected_label = st.selectbox(
        "Seleccionar paciente",
        list(options.keys()),
        key="report_patient",
    )
    patient_id = options[selected_label]
    patient = get_patient(patient_id)
    sessions = get_patient_sessions(patient_id)

    if patient is None:
        st.error("No se pudo recuperar la información del paciente.")
        return

    report = build_clinical_report(patient, sessions)
    st.text_area("Vista previa", value=report, height=220, disabled=True)
    safe_name = "".join(
        character if character.isalnum() else "_"
        for character in patient["name"].strip().lower()
    ).strip("_")
    st.download_button(
        "Descargar informe TXT",
        data=report.encode("utf-8"),
        file_name=f"informe_prom_acu_{safe_name or patient_id}.txt",
        mime="text/plain",
        type="primary",
    )
    st.caption(
        "Informe descriptivo de seguimiento. No constituye diagnóstico, "
        "indicación terapéutica ni certificado médico."
    )


def main() -> None:
    """Initialize storage and render the selected application page."""
    try:
        init_db()
    except sqlite3.Error as error:
        st.error(f"No se pudo inicializar la base de datos: {error}")
        st.stop()

    with st.sidebar:
        st.title("PROM-ACU")
        page = st.radio(
            "Navegación",
            [
                "Inicio",
                "Registro de paciente",
                "Registro de sesión",
                "Dashboard médico",
                "Informe clínico",
            ],
        )
        st.divider()
        st.caption("Demo MVP · Datos almacenados localmente")

    pages = {
        "Inicio": render_home,
        "Registro de paciente": render_patient_registration,
        "Registro de sesión": render_session_registration,
        "Dashboard médico": render_dashboard,
        "Informe clínico": render_report,
    }
    pages[page]()


if __name__ == "__main__":
    main()
